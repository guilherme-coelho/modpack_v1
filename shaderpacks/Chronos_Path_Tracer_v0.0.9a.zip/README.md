# Chronos Path Tracer
A random path tracing shader for MC, and the result of what happens when you go into path tracing almost completely blind.